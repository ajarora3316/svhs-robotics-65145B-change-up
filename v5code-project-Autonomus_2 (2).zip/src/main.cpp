/*----------------------------------------------------------------------------*/
/*                                                                            */
/*    Module:       main.cpp                                                  */
/*    Author:       Wyatt Mattson                                             */
/*    Created:      Wed Feb 24 2021                                           */
/*    Description:  Our Autonomous Code :D                                    */
/*                                                                            */
/*----------------------------------------------------------------------------*/

// ---- START VEXCODE CONFIGURED DEVICES ----
// Robot Configuration:
// [Name]               [Type]        [Port(s)]
// Drivetrain           drivetrain    1, 2, 3, 4      
// Roller               motor         5               
// LeftIntake           motor         6               
// RightIntake          motor         7               
// ---- END VEXCODE CONFIGURED DEVICES ----

#include "vex.h"

using namespace vex;

int main() {
  // Initializing Robot Configuration. DO NOT REMOVE!
  vexcodeInit();

//Move forward towards first blue ball

  Drivetrain.driveFor(forward,24,inches);

  // Spin both intakes, idrk how to do them both at the same time, in order to cycle ball

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

 // Turn Right to face next blue ball

  Drivetrain.turn(right);

 // Run into ball in order to slurp it up

  Drivetrain.driveFor(forward,12,inches);

  // Spin so slurp

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  // Throw both balls into goal

  Roller.spinFor(forward,720,degrees);

  // Bac upp

  Drivetrain.driveFor(reverse,12,inches);

  // Go towards top goal

  Drivetrain.turnFor(left,45,degrees);
  Drivetrain.driveFor(forward,12,inches);

  // Turn to 3rd ball and move into it

  Drivetrain.turnFor(right,135,degrees);
  Drivetrain.driveFor(forward,12,inches);

  // Intake ball

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  // Score

  Roller.spinFor(forward,720,degrees);

  // Turn Around & Navigate to top goal

  Drivetrain.driveFor(reverse,8,inches);
  Drivetrain.turnFor(left,360,degrees);

  // Descore 

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  // Move & Throw Red Ball aside

  Drivetrain.driveFor(reverse,4,inches);
  Drivetrain.turnFor(left,90,degrees);

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  Drivetrain.turnFor(right,360,degrees);

  // Navigate to "loose" balls on the feild

  Drivetrain.driveFor(forward,16,inches);
  Drivetrain.turn(left);
  Drivetrain.driveFor(forward,30,inches);

  // Intake ball

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  // Backup and get secont ball       (Peep the spelling tho)

  Drivetrain.driveFor(reverse,4,inches);
  Drivetrain.turnFor(left,45,degrees);
  Drivetrain.driveFor(forward,6,inches);

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  /* back up in order to get 2nd goal finished
  This block will take both balls out of the goal
  and throw 3 blue ones in */

  Drivetrain.driveFor(reverse,24,inches);
  Drivetrain.turnFor(left,45,degrees);
  Drivetrain.driveFor(forward,12,inches);

  LeftIntake.spinFor(forward,720,degrees);
  RightIntake.spinFor(forward,720,degrees);

  // release red ball, and set up next movement

  Drivetrain.driveFor(reverse,8,inches);
  Drivetrain.turnFor(left,90,degrees);

  LeftIntake.spinFor(forward,360,degrees);
  RightIntake.spinFor(forward,360,degrees);

  Drivetrain.turnFor(right,180,degrees);





}
